package com.varsitycollege.youtubeshorttoigstory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.io.File;
import java.net.URL;
import com.github.axet.vget.*;

import android.app.Activity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Get intent, action and MIME type
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {
                handleSendText(intent); // Handle text being sent
            }
        }

    }

    void handleSendText(Intent intent) {
        String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (sharedText != null) {
            // Update UI to reflect text being shared

            //get video link download file
            //upload file to instagram story

            try {
                String url = sharedText;
                String path = "D:\\Manindar\\YTD\\";

                File ff = new File(path);

                VGet v = new VGet(new URL(url), ff);
                v.download();

                //upload to instagram story

                uploadToInstagram(ff);
                   ff.delete();

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    void uploadToInstagram(File ff){

        Uri stickerAssetUri = Uri.parse("your-image-asset-uri-goes-here");
        String sourceApplication = "com.my.app";

// Instantiate implicit intent with ADD_TO_STORY action,
// sticker asset, and background colors

        Intent intent = new Intent("com.instagram.share.ADD_TO_STORY");
        intent.putExtra("source_application", sourceApplication);

        intent.setType("video/mp4");
        intent.putExtra("interactive_asset_uri", stickerAssetUri);
        intent.putExtra("top_background_color", "#33FF33");
        intent.putExtra("bottom_background_color", "#FF00FF");
        intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(ff));

// Instantiate activity and verify it will resolve implicit intent
        Activity activity = getParent();
        activity.grantUriPermission(
                "com.instagram.android", stickerAssetUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (activity.getPackageManager().resolveActivity(intent, 0) != null) {
            activity.startActivityForResult(intent, 0);
        }
    }
}